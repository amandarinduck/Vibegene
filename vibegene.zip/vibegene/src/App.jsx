import { useState, useEffect, useRef, useCallback, useMemo } from "react";

// ── Colors ──────────────────────────────────────────────────────────────────
const BASE_COLORS = { A: "#4ade80", T: "#f87171", G: "#60a5fa", C: "#fbbf24" };
const COMPLEMENT  = { A: "T", T: "A", G: "C", C: "G" };
const FEAT_COLORS = ["#a78bfa","#f97316","#34d399","#60a5fa","#f43f5e","#fbbf24","#e879f9","#22d3ee"];
const TYPE_COLORS = {
  promoter: "#34d399",
  terminator: "#f87171",
  CDS: "#60a5fa",
  "resistance gene": "#f97316",
  "origin of replication": "#fbbf24",
  tag: "#a78bfa",
  "cloning site": "#94a3b8",
  regulatory: "#e879f9",
  "reporter gene": "#22d3ee",
};

// ── Element database ─────────────────────────────────────────────────────────
const ELEMENT_DB = [
  { name: "T7 promoter",         type: "promoter",              seq: "TAATACGACTCACTATA" },
  { name: "T7 promoter (ext)",   type: "promoter",              seq: "TAATACGACTCACTATAGGG" },
  { name: "SP6 promoter",        type: "promoter",              seq: "ATTTAGGTGACACTATAG" },
  { name: "lac promoter",        type: "promoter",              seq: "AATTGTGAGCGGATAACAATT" },
  { name: "tac promoter",        type: "promoter",              seq: "TTGACAATTAATCATCGGCTCGTATAATGTGTGG" },
  { name: "trc promoter",        type: "promoter",              seq: "TTGACAATTAATCATCGGCTCGTATAATGTGTGGAATTGTGAGCGGATAACAATT" },
  { name: "araBAD promoter",     type: "promoter",              seq: "AACGCGTACGAATAATTCTTGAAAGTATTATTTAAATGTGAATCGAATCACAT" },
  { name: "pTet promoter",       type: "promoter",              seq: "TCCCTATCAGTGATAGAGAACGAAAGTCCCTATCAGTGATAGAGAACGAAAGTCCCTATCAGTGATAGAGAACGAAAGT" },
  { name: "EF1a promoter",       type: "promoter",              seq: "GCGCCACTATGGAAAGCGCTCTAGA" },
  { name: "CAG promoter",        type: "promoter",              seq: "CTCGAGGTCGACGGTATCGATAAGCTTGATATCGAATTCCTGCAGCCC" },
  { name: "T7 terminator",       type: "terminator",            seq: "GCTAGTTATTGCTCAGCGG" },
  { name: "rrnB T1 terminator",  type: "terminator",            seq: "TGCCTGGCGGCAGTAGCGCGGTGGTCCCACCTGACCCCATGCCGAACTCAGAAGTGAAACGCCGTAGCGCCGATGGTAGTGTGGGGTCTCCCCATGCGAGAGTAGGGAACTGCCAGGCATCAAATAAAACGAAAGGCTCAGTCGAAAGACTGGGCCTTTCGTTTTATCTGTTGTTTGTCGGTGAACGCTCTCCTGAGTAGGACAAATCCGCCGGGAGCGG" },
  { name: "fd gene II terminator", type: "terminator",          seq: "AATAATTTGTTTAACTTTAAGAAGGAGA" },
  { name: "T4 terminator",       type: "terminator",            seq: "CTCGGTACCAAATTCCAGAAAAGAGGCCTCCCGAAAGGGGGGCCTTTTTTCGTTTTGGTCC" },
  { name: "AmpR",                type: "resistance gene",       seq: "ATGAGTATTCAACATTTCCGTGTCGCCCTTATTCCC" },
  { name: "KanR",                type: "resistance gene",       seq: "ATGATTGAACAAGATGGATTGCACGCAGGTTCTCCGGCC" },
  { name: "CamR",                type: "resistance gene",       seq: "ATGGAGAAAAAAATCACTGGATATACCACCGTTGATATATCCCAATGGCATCGTAAAGAACATTTTGAGGCATTTCAGTCAGTTGCTCAATGTACCTATAACC" },
  { name: "TetR",                type: "resistance gene",       seq: "ATGTCTAGAGAAAGCCTGTTCAGCCAAATCAATCTTAAAATCGAG" },
  { name: "ZeoR",                type: "resistance gene",       seq: "ATGGCCAAGTTGACCAGTGCCGTTCCGGTGCTCACCGCGCGCGACGTCGCCGGAGCGGTCGAGTTCTGGACCGACCGGCTCGGGTTCTCCCGGGACTTCGTGGAGGACGACTTCGCCGGTGTGGTCCGGGACGACGTGACC" },
  { name: "pMB1/ColE1 ori",      type: "origin of replication", seq: "TTTTCAGAGCTTGGTTGACGGCAATTTCGATGATGCAGCTTGGGCGCAGGGTCGATGCGACGCAATCGTCCGATCCGGAGCCGGGACTGTCGGGCGTACACAAATCGCCCGCAGAAGCGCGGCCGTCTGGACCGATGGCTGTGTAGAAGTACTCGCCGATAGTGGAAACCGACGCCCCAGCACTCGTCCGAGGGCAAAGG" },
  { name: "f1 ori",              type: "origin of replication", seq: "ACGCGCCCTGTAGCGGCGCATTAAGCGCGGCGGGTGTGGTGGTTACGCGCAGCGTGACCGCTACACTTGCCAGCGCCCTAGCGCCCGCTCCTTTCGCTTTCTTCCCTTCCTTTCTCGCCACGTTCGCCGGCTTTCCCCGTCAAGCTCTAAATCGGGGGCTCCCTTTAGGGTTCCGATTTAGTGCTTTACGGCACCTCGACCCC" },
  { name: "p15A ori",            type: "origin of replication", seq: "AACGCGCGGGGAGAGGCGGTTTGCGTATTGGGCGCTCTTCCGCTTCCTCGCTCACTGACTCGCTGCGCTCGGTCGTTCGGCTGCGGCGAGCGGTATCAGGCTACGGCGTTTGGCGATTCGCCTTGAGTCTCTACTGGGCGAAATCAACGGGCTGGTCCC" },
  { name: "His-tag (6x)",        type: "tag",                   seq: "CACCACCACCACCAC" },
  { name: "FLAG tag",            type: "tag",                   seq: "GACTACAAAGACCATGACGGTGATTATAAAGATCATGACATCGATTACAAGGATGACGATGACAAG" },
  { name: "HA tag",              type: "tag",                   seq: "TACCCATACGATGTTCCAGATTACGCT" },
  { name: "Myc tag",             type: "tag",                   seq: "GAACAAAAACTCATCTCAGAAGAGGATCTG" },
  { name: "V5 tag",              type: "tag",                   seq: "GGTAAGCCTATCCCTAACCCTCTCCTCGGTCTCGATTCTACG" },
  { name: "EGFP",                type: "reporter gene",         seq: "ATGGTGAGCAAGGGCGAGGAGCTGTTCACCGGGGTGGTGCCCATCCTGGTCGAGCTGGACGGCGACGTAAACGGCCACAAGTTCAGCGTGTCCGGCGAGGGCGAGGGCGATGCCACCTACGGCAAGCTGACCCTGAAGTTCATCTGCACCACCGGCAAGCTGCCCGTGCCCTGGCCCACC" },
  { name: "mCherry",             type: "reporter gene",         seq: "ATGGTGAGCAAGGGCGAGGAGGATAACATGGCCATCATCAAGGAGTTCATGCGCTTCAAGGTGCACATGGAGGGCTCCGTGAACGGCCACGAGTTCGAGATCGAGGGCGAGGGCGAGGGCCGCCCCTACGAGGGCACCCAGACCGCCAAGCTGAAGGTGACC" },
  { name: "LacZ alpha",          type: "reporter gene",         seq: "ATGACCATGATTACGAATTCACTGGCCGTCGTTTTACAACGTCGTGACTGGGAAAACCCTGGCG" },
  { name: "lacO operator",       type: "regulatory",            seq: "AATTGTGAGCGGATAACAATT" },
  { name: "MCS (pUC)",           type: "cloning site",          seq: "AAGCTTGCATGCCTGCAGGTCGACGGATCCCCGGGAATTCGAGCTC" },
  { name: "loxP site",           type: "regulatory",            seq: "ATAACTTCGTATAATGTATGCTATACGAAGTTAT" },
  { name: "FRT site",            type: "regulatory",            seq: "GAAGTTCCTATTCTCTAGAAAGTATAGGAACTTC" },
  { name: "Kozak sequence",      type: "regulatory",            seq: "GCCACCATGG" },
  { name: "RBS",                 type: "regulatory",            seq: "AGGAGG" },
  { name: "WPRE",                type: "regulatory",            seq: "ATCAACCTCTGGATTACAAAATTTGTGAAAGATTGACTGGTATTCTTAACTATGTTGCTCCTTTTACGCTATGTGGATACGCTGCTTTAATGCCTTTGTATCATGCTATTGCTTCCCGTATGGCTTTCATTTTCTCCTCCTTGTATAAATCCTGGTTGCTGTCTCTTTATGAGG" },
];

// ── Utils ────────────────────────────────────────────────────────────────────
function comp(seq) {
  return seq.split("").map(b => COMPLEMENT[b] || b).join("");
}
function revComp(seq) {
  return comp(seq).split("").reverse().join("");
}
function gcPct(seq) {
  if (!seq.length) return "0.0";
  return (((seq.match(/[GC]/gi) || []).length / seq.length) * 100).toFixed(1);
}
function meltTm(seq) {
  const gc = (seq.match(/[GC]/gi) || []).length;
  const at = (seq.match(/[AT]/gi) || []).length;
  if (seq.length < 14) return (gc * 4 + at * 2).toFixed(1);
  return (64.9 + 41 * (gc - 16.4) / seq.length).toFixed(1);
}
function cleanSeq(s) {
  return s.toUpperCase().replace(/[^ATGCRYSWKMBDHVN]/g, "");
}
function countBases(s) {
  return {
    A: (s.match(/A/g) || []).length,
    T: (s.match(/T/g) || []).length,
    G: (s.match(/G/g) || []).length,
    C: (s.match(/C/g) || []).length,
  };
}

// ── Annotation engine ────────────────────────────────────────────────────────
function scoreAlignment(a, b) {
  if (!a.length || !b.length) return 0;
  let matches = 0;
  const len = Math.min(a.length, b.length);
  for (let i = 0; i < len; i++) {
    if (a[i] === b[i]) matches++;
  }
  return matches / Math.max(a.length, b.length);
}

function findBestHit(query, pattern, minId) {
  const pLen = pattern.length;
  const qLen = query.length;
  if (!pLen || qLen < pLen) return null;

  const rcPattern = revComp(pattern);
  let best = null;

  for (let i = 0; i <= qLen - pLen; i++) {
    const win = query.slice(i, i + pLen);
    const fwdScore = scoreAlignment(win, pattern);
    if (fwdScore >= minId && (!best || fwdScore > best.identity)) {
      best = { start: i, end: i + pLen - 1, identity: fwdScore, strand: 1 };
    }
    const revScore = scoreAlignment(win, rcPattern);
    if (revScore >= minId && (!best || revScore > best.identity)) {
      best = { start: i, end: i + pLen - 1, identity: revScore, strand: -1 };
    }
  }
  return best;
}

function annotate(sequence, minId = 0.85, extraDb = []) {
  const results = [];
  const used = [];
  const fullDb = [...ELEMENT_DB, ...extraDb];
  const sorted = [...fullDb].sort((a, b) => b.seq.length - a.seq.length);

  for (const el of sorted) {
    if (el.seq.length > sequence.length) continue;
    const hit = findBestHit(sequence, el.seq, minId);
    if (!hit) continue;

    const overlaps = used.some(u =>
      u.type === el.type &&
      Math.max(0, Math.min(hit.end, u.end) - Math.max(hit.start, u.start)) >
      0.5 * Math.min(hit.end - hit.start, u.end - u.start)
    );
    if (overlaps) continue;

    results.push({ ...hit, name: el.name, type: el.type });
    used.push({ start: hit.start, end: hit.end, type: el.type });
  }

  return results.sort((a, b) => a.start - b.start);
}

// ── File parsers ─────────────────────────────────────────────────────────────
function parseFasta(text) {
  const lines = text.split(/\r?\n/);
  let name = "Imported", seq = "", inSeq = false;
  for (const line of lines) {
    if (line.startsWith(">")) {
      if (inSeq) break;
      name = line.slice(1).trim().split(/\s+/)[0] || "Imported";
      inSeq = true;
    } else if (inSeq) {
      seq += line.trim();
    }
  }
  if (!seq) throw new Error("No sequence found in FASTA file");
  return { name, sequence: cleanSeq(seq), features: [] };
}

function parseGenBank(text) {
  const lines = text.split(/\r?\n/);
  let name = "Imported";
  const locusLine = lines.find(l => l.startsWith("LOCUS"));
  if (locusLine) name = locusLine.split(/\s+/)[1] || "Imported";
  const defLine = lines.find(l => l.startsWith("DEFINITION"));
  if (defLine) name = defLine.replace("DEFINITION", "").trim().replace(/\.$/, "").slice(0, 30) || name;

  let inOrigin = false, rawSeq = "";
  for (const line of lines) {
    if (line.startsWith("ORIGIN")) { inOrigin = true; continue; }
    if (line.startsWith("//")) { inOrigin = false; continue; }
    if (inOrigin) rawSeq += line.replace(/[^a-zA-Z]/g, "");
  }
  if (!rawSeq) throw new Error("No ORIGIN sequence found");
  const sequence = cleanSeq(rawSeq);

  const features = [];
  const FEAT_TYPES = ["CDS","gene","promoter","misc_feature","rep_origin","terminator","RBS"];
  let i = 0;
  while (i < lines.length) {
    const trimmed = lines[i].trim();
    const matchedType = FEAT_TYPES.find(ft => trimmed.startsWith(ft));
    if (matchedType) {
      const locStr = trimmed.slice(matchedType.length).trim();
      let start = 0, end = 0, strand = 1;
      const cm = locStr.match(/complement\((\d+)\.\.(\d+)\)/);
      const fm = locStr.match(/(\d+)\.\.(\d+)/);
      if (cm) { start = parseInt(cm[1]) - 1; end = parseInt(cm[2]) - 1; strand = -1; }
      else if (fm) { start = parseInt(fm[1]) - 1; end = parseInt(fm[2]) - 1; }
      let label = matchedType;
      for (let j = i + 1; j < Math.min(i + 10, lines.length); j++) {
        const q = lines[j].trim();
        const lm = q.match(/\/(?:label|gene|locus_tag|note)="([^"]+)"/);
        if (lm) { label = lm[1].slice(0, 16); break; }
      }
      if (end > start) {
        features.push({ name: label, start, end, strand, color: FEAT_COLORS[features.length % FEAT_COLORS.length] });
      }
    }
    i++;
  }
  return { name, sequence, features };
}

function parseSnapGene(buffer) {
  const view = new DataView(buffer);
  let offset = 0;
  let sequence = "";
  const features = [];

  while (offset < buffer.byteLength - 5) {
    const segType = view.getUint8(offset);
    const segLen = view.getUint32(offset + 1, false);
    offset += 5;
    if (segLen === 0 || offset + segLen > buffer.byteLength) break;

    if (segType === 0x00) {
      const bytes = new Uint8Array(buffer, offset + 1, segLen - 1);
      sequence = cleanSeq(new TextDecoder().decode(bytes));
    } else if (segType === 0x0A) {
      try {
        const xmlStr = new TextDecoder().decode(new Uint8Array(buffer, offset, segLen));
        const doc = new DOMParser().parseFromString(xmlStr, "text/xml");
        doc.querySelectorAll("Feature").forEach(el => {
          const featName = el.getAttribute("name") || "Feature";
          const swapped = el.getAttribute("swappedSegments") === "true";
          const seg = el.querySelector("Segment");
          if (seg) {
            const rangeStr = seg.getAttribute("range") || "";
            const m = rangeStr.match(/(\d+)-(\d+)/);
            if (m) {
              features.push({
                name: featName.slice(0, 16),
                start: parseInt(m[1]),
                end: parseInt(m[2]),
                strand: swapped ? -1 : 1,
                color: FEAT_COLORS[features.length % FEAT_COLORS.length],
              });
            }
          }
        });
      } catch (e) { /* skip */ }
    }
    offset += segLen;
  }

  if (!sequence) throw new Error("Could not extract sequence from .dna file");
  return { name: "SnapGene Import", sequence, features };
}

async function parseFile(file) {
  const ext = file.name.split(".").pop().toLowerCase();
  if (ext === "dna") {
    const buf = await file.arrayBuffer();
    return parseSnapGene(buf);
  }
  const text = await file.text();
  if (["fasta","fa","fna","ffn","faa"].includes(ext) || text.trimStart().startsWith(">")) {
    return parseFasta(text);
  }
  if (["gb","gbk","genbank"].includes(ext) || (text.includes("LOCUS") && text.includes("ORIGIN"))) {
    return parseGenBank(text);
  }
  const seq = cleanSeq(text);
  if (seq.length < 4) throw new Error("No valid DNA sequence found");
  return { name: "Imported", sequence: seq, features: [] };
}

// ── Samples ───────────────────────────────────────────────────────────────────
const SAMPLES = {
  pUC19: "ATGACCATGATTACGCCAAGCTTGCATGCCTGCAGGTCGACGGATCCCCGGGAATTCGAGCTCGGTACCCGGGGATCCTCTAGAGTCGACCTGCAGGCATGCAAGCTTGGCGTAATCATGGTCATAGCTGTTTCCTGTGTGAAATTGTTATCCGCT",
  GFP:   "ATGGTGAGCAAGGGCGAGGAGCTGTTCACCGGGGTGGTGCCCATCCTGGTCGAGCTGGACGGCGACGTAAACGGCCACAAGTTCAGCGTGTCCGGCGAGGGCGAGGGCGATGCCACCTACGGCAAGCTGACCCTGAAGTTCATCTGCACCACC",
  T7:    "TAATACGACTCACTATAGGGGAATTGTGAGCGGATAACAATTCCCCTCTAGAAATAATTTTGTTTAACTTTAAGAAGGAGATATA",
};

const DEMO_FEATURES = [
  { name: "MCS",    start: 10, end: 40,  color: "#a78bfa", strand: 1,  type: "cloning site" },
  { name: "T7 Prom",start: 55, end: 75,  color: "#34d399", strand: 1,  type: "promoter" },
  { name: "AmpR",   start: 90, end: 130, color: "#f97316", strand: -1, type: "resistance gene" },
];

// ── FileUpload ────────────────────────────────────────────────────────────────
function FileUpload({ onLoad, onError }) {
  const [dragging, setDragging] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleFile(file) {
    if (!file) return;
    setLoading(true);
    try {
      const result = await parseFile(file);
      onLoad(result, file.name);
    } catch (e) {
      onError(e.message || "Failed to parse file");
    } finally {
      setLoading(false);
    }
  }

  function onDrop(e) {
    e.preventDefault();
    setDragging(false);
    handleFile(e.dataTransfer.files[0]);
  }

  function onInputChange(e) {
    handleFile(e.target.files[0]);
    e.target.value = "";
  }

  return (
    <div
      onDrop={onDrop}
      onDragOver={e => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      style={{ position: "relative", borderRadius: 10, overflow: "hidden" }}
    >
      {/* The input IS the button — directly styled, nothing intercepting it */}
      <input
        type="file"
        accept=".fasta,.fa,.fna,.gb,.gbk,.genbank,.dna,.txt"
        onChange={onInputChange}
        disabled={loading}
        style={{
          display: "block",
          width: "100%",
          padding: "14px",
          fontSize: 14,
          fontFamily: "'JetBrains Mono', monospace",
          fontWeight: 700,
          color: loading ? "#475569" : "#0a0f1e",
          background: loading ? "#1e293b" : dragging ? "#22c55e" : "#4ade80",
          border: "none",
          borderRadius: 10,
          cursor: loading ? "not-allowed" : "pointer",
          boxSizing: "border-box",
          transition: "background 0.2s",
        }}
      />
      {/* Label overlay so we control the text (pointer-events:none so input still receives clicks) */}
      <div style={{
        position: "absolute", inset: 0, display: "flex", alignItems: "center",
        justifyContent: "center", gap: 8, pointerEvents: "none",
        fontFamily: "'JetBrains Mono', monospace", fontWeight: 700,
        fontSize: 14, color: loading ? "#475569" : "#0a0f1e",
      }}>
        {loading ? "⏳ Parsing…" : dragging ? "Drop file here" : "📂 Choose File"}
      </div>
    </div>
  );
}

// ── BaseSpan ──────────────────────────────────────────────────────────────────
function BaseSpan({ base, selected, onTap }) {
  const color = BASE_COLORS[base] || "#94a3b8";
  return (
    <span
      onClick={onTap}
      style={{
        display: "inline-block", width: 16, height: 22, lineHeight: "22px",
        textAlign: "center", fontSize: 13, fontWeight: 700,
        color: selected ? "#0f172a" : color,
        background: selected ? color : "transparent",
        borderRadius: 3, cursor: "pointer", userSelect: "none",
        WebkitTapHighlightColor: "transparent",
      }}
    >
      {base}
    </span>
  );
}

// ── SequenceViewer ────────────────────────────────────────────────────────────
function SequenceViewer({ sequence, selection, onTapBase, showComp }) {
  const CHUNK = 40;
  const chunks = [];
  for (let i = 0; i < sequence.length; i += CHUNK) {
    chunks.push(sequence.slice(i, i + CHUNK));
  }

  return (
    <div style={{ fontFamily: "'JetBrains Mono', monospace" }}>
      {chunks.map((chunk, ci) => {
        const offset = ci * CHUNK;
        return (
          <div key={ci} style={{ marginBottom: 16 }}>
            <div style={{ color: "#475569", fontSize: 10, marginBottom: 3, userSelect: "none" }}>
              {String(offset + 1).padStart(4, " ")}
            </div>
            <div style={{ display: "flex", flexWrap: "wrap" }}>
              {chunk.split("").map((base, idx) => {
                const gi = offset + idx;
                const sel = selection != null && gi >= Math.min(selection[0], selection[1]) && gi <= Math.max(selection[0], selection[1]);
                return <BaseSpan key={gi} base={base} selected={sel} onTap={() => onTapBase(gi)} />;
              })}
            </div>
            {showComp && (
              <div style={{ display: "flex", flexWrap: "wrap", opacity: 0.4, marginTop: 2 }}>
                {comp(chunk).split("").map((base, idx) => (
                  <span key={idx} style={{ display: "inline-block", width: 16, height: 16, lineHeight: "16px", textAlign: "center", fontSize: 11, fontWeight: 600, color: BASE_COLORS[base] || "#94a3b8", userSelect: "none" }}>
                    {base}
                  </span>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ── PlasmidMap ────────────────────────────────────────────────────────────────
function PlasmidMap({ sequence, features }) {
  const wrapRef = useRef(null);
  const [svgSize, setSvgSize] = useState(300);

  useEffect(() => {
    if (!wrapRef.current) return;
    const observer = new ResizeObserver(entries => {
      const w = entries[0].contentRect.width;
      setSvgSize(Math.min(Math.max(w - 16, 200), 420));
    });
    observer.observe(wrapRef.current);
    return () => observer.disconnect();
  }, []);

  const cx = svgSize / 2;
  const cy = svgSize / 2;
  const ringR = svgSize * 0.34;
  const seqLen = sequence.length || 1;

  function posToAngle(pos) {
    return (pos / seqLen) * 2 * Math.PI - Math.PI / 2;
  }

  function makeArc(startPos, endPos, innerR, outerR) {
    const a1 = posToAngle(startPos);
    const a2 = posToAngle(endPos);
    const large = (endPos - startPos) / seqLen > 0.5 ? 1 : 0;
    const x1o = cx + outerR * Math.cos(a1);
    const y1o = cy + outerR * Math.sin(a1);
    const x2o = cx + outerR * Math.cos(a2);
    const y2o = cy + outerR * Math.sin(a2);
    const x2i = cx + innerR * Math.cos(a2);
    const y2i = cy + innerR * Math.sin(a2);
    const x1i = cx + innerR * Math.cos(a1);
    const y1i = cy + innerR * Math.sin(a1);
    return `M ${x1o} ${y1o} A ${outerR} ${outerR} 0 ${large} 1 ${x2o} ${y2o} L ${x2i} ${y2i} A ${innerR} ${innerR} 0 ${large} 0 ${x1i} ${y1i} Z`;
  }

  const tickCount = 8;
  const ticks = Array.from({ length: tickCount }, (_, i) => {
    const angle = (i / tickCount) * 2 * Math.PI - Math.PI / 2;
    return {
      pos: Math.round((i / tickCount) * seqLen),
      x1: cx + (ringR - 6) * Math.cos(angle),
      y1: cy + (ringR - 6) * Math.sin(angle),
      x2: cx + (ringR + 6) * Math.cos(angle),
      y2: cy + (ringR + 6) * Math.sin(angle),
      tx: cx + (ringR + 18) * Math.cos(angle),
      ty: cy + (ringR + 18) * Math.sin(angle),
    };
  });

  const validFeatures = features.filter(f => f.end > f.start);

  return (
    <div ref={wrapRef} style={{ width: "100%" }}>
      <svg width={svgSize} height={svgSize} style={{ display: "block", margin: "0 auto" }}>
        <circle cx={cx} cy={cy} r={ringR} fill="none" stroke="#1e293b" strokeWidth={16} />
        <circle cx={cx} cy={cy} r={ringR} fill="none" stroke="#334155" strokeWidth={1} />
        {validFeatures.map((f, i) => (
          <path
            key={i}
            d={makeArc(f.start, f.end, ringR - 10, ringR + 10)}
            fill={f.color || TYPE_COLORS[f.type] || "#64748b"}
            opacity={0.85}
          />
        ))}
        {validFeatures.map((f, i) => {
          const midAngle = posToAngle((f.start + f.end) / 2);
          const lx = cx + (ringR + 24) * Math.cos(midAngle);
          const ly = cy + (ringR + 24) * Math.sin(midAngle);
          const label = f.name.length > 10 ? f.name.slice(0, 9) + "…" : f.name;
          return (
            <text key={i} x={lx} y={ly} textAnchor="middle" dominantBaseline="middle"
              fontSize={svgSize < 260 ? 7 : 9} fontFamily="monospace"
              fill={f.color || TYPE_COLORS[f.type] || "#64748b"} fontWeight="700">
              {label}
            </text>
          );
        })}
        {ticks.map((t, i) => (
          <g key={i}>
            <line x1={t.x1} y1={t.y1} x2={t.x2} y2={t.y2} stroke="#334155" strokeWidth={1} />
            <text x={t.tx} y={t.ty} textAnchor="middle" dominantBaseline="middle"
              fontSize={8} fill="#475569" fontFamily="monospace">
              {t.pos}
            </text>
          </g>
        ))}
        <circle cx={cx} cy={cy} r={ringR * 0.52} fill="#0a0f1e" />
        <text x={cx} y={cy - 8} textAnchor="middle" fontSize={13} fill="#94a3b8" fontFamily="monospace" fontWeight="700">
          {seqLen} bp
        </text>
        <text x={cx} y={cy + 10} textAnchor="middle" fontSize={9} fill="#475569" fontFamily="monospace">
          plasmid
        </text>
      </svg>
    </div>
  );
}

// ── StatsDrawer ───────────────────────────────────────────────────────────────
function StatsDrawer({ sequence, selSeq }) {
  const [open, setOpen] = useState(false);
  const counts = countBases(sequence);

  return (
    <div style={{ borderTop: "1px solid #1e293b", background: "#0f172a" }}>
      <button
        onClick={() => setOpen(o => !o)}
        style={{ width: "100%", background: "none", border: "none", padding: "10px 16px", display: "flex", alignItems: "center", justifyContent: "space-between", color: "#64748b", fontFamily: "'JetBrains Mono', monospace", fontSize: 11, cursor: "pointer", letterSpacing: "0.08em", WebkitTapHighlightColor: "transparent" }}
      >
        <span>📊 STATS{selSeq ? ` · ${selSeq.length} bp selected` : ` · ${sequence.length} bp`}</span>
        <span style={{ transform: open ? "rotate(180deg)" : "none", transition: "transform 0.2s", display: "inline-block" }}>▲</span>
      </button>

      {open && (
        <div style={{ padding: "0 16px 16px", display: "flex", flexDirection: "column", gap: 14 }}>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {[
              { label: "GC%", value: gcPct(sequence) + "%" },
              { label: "Tm",  value: meltTm(sequence) + " °C" },
              { label: "Length", value: sequence.length + " bp" },
            ].map(s => (
              <div key={s.label} style={{ background: "#1e293b", borderRadius: 8, padding: "7px 12px", display: "flex", flexDirection: "column", gap: 2 }}>
                <span style={{ color: "#475569", fontSize: 9, letterSpacing: "0.1em" }}>{s.label}</span>
                <span style={{ color: "#e2e8f0", fontSize: 14, fontWeight: 700 }}>{s.value}</span>
              </div>
            ))}
          </div>

          <div>
            {["A", "T", "G", "C"].map(base => {
              const pct = sequence.length ? ((counts[base] / sequence.length) * 100).toFixed(1) : 0;
              return (
                <div key={base} style={{ marginBottom: 7 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
                    <span style={{ color: BASE_COLORS[base], fontWeight: 700, fontSize: 12 }}>{base}</span>
                    <span style={{ color: "#64748b", fontSize: 11 }}>{counts[base]} ({pct}%)</span>
                  </div>
                  <div style={{ height: 4, background: "#1e293b", borderRadius: 3, overflow: "hidden" }}>
                    <div style={{ height: "100%", width: pct + "%", background: BASE_COLORS[base], borderRadius: 3, transition: "width 0.3s" }} />
                  </div>
                </div>
              );
            })}
          </div>

          {selSeq && (
            <div style={{ background: "#1e293b", borderRadius: 10, padding: 12 }}>
              <div style={{ color: "#64748b", fontSize: 10, letterSpacing: "0.1em", marginBottom: 8 }}>SELECTION · {selSeq.length} bp</div>
              <div style={{ color: "#4ade80", wordBreak: "break-all", fontSize: 12, marginBottom: 6 }}>
                {selSeq.slice(0, 50)}{selSeq.length > 50 ? "…" : ""}
              </div>
              <div style={{ display: "flex", gap: 16, marginBottom: 10 }}>
                <div>
                  <div style={{ color: "#475569", fontSize: 9 }}>GC%</div>
                  <div style={{ color: "#e2e8f0", fontWeight: 700 }}>{gcPct(selSeq)}%</div>
                </div>
                <div>
                  <div style={{ color: "#475569", fontSize: 9 }}>Tm</div>
                  <div style={{ color: "#e2e8f0", fontWeight: 700 }}>{meltTm(selSeq)} °C</div>
                </div>
              </div>
              <button
                onClick={() => navigator.clipboard.writeText(selSeq)}
                style={{ background: "#0f172a", color: "#60a5fa", border: "none", borderRadius: 6, padding: 8, fontSize: 12, cursor: "pointer", fontFamily: "monospace", width: "100%" }}
              >
                Copy Selection
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── AnnotateTab ───────────────────────────────────────────────────────────────
const ELEMENT_TYPES = [
  "promoter", "terminator", "CDS", "resistance gene",
  "origin of replication", "tag", "cloning site", "regulatory",
  "reporter gene", "other",
];

function AnnotateTab({ sequence, onAddFeatures, customDb, onCustomDbChange }) {
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState(null);
  const [threshold, setThreshold] = useState(85);
  const [added, setAdded] = useState(new Set());
  const [filterType, setFilterType] = useState("all");

  // Custom element form state
  const [dbTab, setDbTab] = useState("annotate"); // "annotate" | "database"
  const [newEl, setNewEl] = useState({ name: "", type: "promoter", seq: "" });
  const [elError, setElError] = useState("");
  const [dbFilter, setDbFilter] = useState("all");

  const allTypes = useMemo(() => {
    if (!results) return ["all"];
    return ["all", ...new Set(results.map(r => r.type))];
  }, [results]);

  const totalDb = ELEMENT_DB.length + customDb.length;

  function runAnnotation() {
    if (!sequence || sequence.length < 10) {
      alert("Please load a sequence first.");
      return;
    }
    setRunning(true);
    setAdded(new Set());
    setResults(null);
    setTimeout(() => {
      try {
        const hits = annotate(sequence, threshold / 100, customDb);
        setResults(hits);
      } catch (e) {
        alert("Annotation error: " + e.message);
      } finally {
        setRunning(false);
      }
    }, 20);
  }

  function addHit(hit, idx) {
    const color = TYPE_COLORS[hit.type] || FEAT_COLORS[idx % FEAT_COLORS.length];
    onAddFeatures([{ name: hit.name, start: hit.start, end: hit.end, strand: hit.strand, color, type: hit.type }]);
    setAdded(prev => new Set([...prev, idx]));
  }

  function addAll() {
    const toAdd = (results || [])
      .filter((_, i) => !added.has(i))
      .map((hit, i) => ({
        name: hit.name, start: hit.start, end: hit.end, strand: hit.strand,
        color: TYPE_COLORS[hit.type] || FEAT_COLORS[i % FEAT_COLORS.length],
        type: hit.type,
      }));
    onAddFeatures(toAdd);
    setAdded(new Set((results || []).map((_, i) => i)));
  }

  function handleAddCustomEl() {
    setElError("");
    const name = newEl.name.trim();
    const seq  = cleanSeq(newEl.seq.trim());
    if (!name) { setElError("Name is required."); return; }
    if (seq.length < 6) { setElError("Sequence must be at least 6 bases."); return; }
    const isDupe = [...ELEMENT_DB, ...customDb].some(
      el => el.name.toLowerCase() === name.toLowerCase()
    );
    if (isDupe) { setElError("An element with this name already exists."); return; }
    onCustomDbChange([...customDb, { name, type: newEl.type, seq, custom: true }]);
    setNewEl({ name: "", type: "promoter", seq: "" });
  }

  function removeCustomEl(idx) {
    onCustomDbChange(customDb.filter((_, i) => i !== idx));
  }

  const filtered = results
    ? (filterType === "all" ? results : results.filter(r => r.type === filterType))
    : null;

  const dbFiltered = dbFilter === "all"
    ? customDb
    : customDb.filter(el => el.type === dbFilter);

  const customTypes = ["all", ...new Set(customDb.map(el => el.type))];

  const inputSt = {
    background: "#1e293b", border: "1px solid #334155", borderRadius: 8,
    color: "#e2e8f0", fontFamily: "'JetBrains Mono', monospace",
    fontSize: 12, padding: "9px 12px", outline: "none",
    width: "100%", boxSizing: "border-box",
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>

      {/* Sub-tab switcher */}
      <div style={{ display: "flex", background: "#0f172a", borderRadius: 10, border: "1px solid #1e293b", overflow: "hidden" }}>
        {[
          { id: "annotate", label: "🔬 Annotate" },
          { id: "database", label: `🗄 My Elements (${customDb.length})` },
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setDbTab(t.id)}
            style={{ flex: 1, background: dbTab === t.id ? "#1e293b" : "none", color: dbTab === t.id ? "#4ade80" : "#475569", border: "none", borderBottom: dbTab === t.id ? "2px solid #4ade80" : "2px solid transparent", padding: "10px 8px", fontSize: 11, fontWeight: 700, cursor: "pointer", fontFamily: "monospace", transition: "all 0.15s" }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ── ANNOTATE PANEL ── */}
      {dbTab === "annotate" && (
        <>
          <div style={{ background: "linear-gradient(135deg,#0f2027,#203a43,#0f2027)", borderRadius: 12, padding: 16, border: "1px solid #1e3a4a" }}>
            <div style={{ fontFamily: "'Syne',sans-serif", fontSize: 15, fontWeight: 800, color: "#4ade80", marginBottom: 4 }}>⬡ Auto-Annotate</div>
            <div style={{ color: "#64748b", fontSize: 11, lineHeight: 1.6 }}>
              Searches against {ELEMENT_DB.length} built-in elements{customDb.length > 0 ? ` + ${customDb.length} custom` : ""} — promoters, resistance genes, tags, origins, reporters, and more.
            </div>
          </div>

          <div style={{ background: "#0f172a", border: "1px solid #1e293b", borderRadius: 10, padding: 14, display: "flex", flexDirection: "column", gap: 12 }}>
            <div>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                <span style={{ color: "#94a3b8", fontSize: 11 }}>Min. Identity</span>
                <span style={{ color: "#4ade80", fontWeight: 700, fontSize: 13 }}>{threshold}%</span>
              </div>
              <input
                type="range" min={70} max={100} value={threshold}
                onChange={e => setThreshold(Number(e.target.value))}
                style={{ width: "100%", accentColor: "#4ade80", cursor: "pointer" }}
              />
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 9, color: "#334155", marginTop: 2 }}>
                <span>70% permissive</span><span>100% exact</span>
              </div>
            </div>
            <button
              onClick={runAnnotation}
              disabled={running || !sequence}
              style={{ background: (running || !sequence) ? "#1e293b" : "#4ade80", color: (running || !sequence) ? "#475569" : "#0a0f1e", border: "none", borderRadius: 8, padding: 12, fontSize: 13, fontWeight: 700, cursor: (running || !sequence) ? "not-allowed" : "pointer", fontFamily: "monospace", transition: "all 0.2s" }}
            >
              {running ? "🔍 Searching…" : "🔬 Run Annotation"}
            </button>
          </div>

          {running && (
            <div style={{ textAlign: "center", padding: "32px 0", color: "#475569", fontSize: 12 }}>
              Scanning {sequence.length} bp against {totalDb} elements…
            </div>
          )}

          {results && !running && (
            <>
              <div style={{ background: "#0f172a", border: "1px solid #1e293b", borderRadius: 10, padding: "12px 14px", display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ fontSize: 22 }}>🎯</div>
                <div style={{ flex: 1 }}>
                  <div style={{ color: "#e2e8f0", fontWeight: 700, fontSize: 14 }}>{results.length} element{results.length !== 1 ? "s" : ""} found</div>
                  <div style={{ color: "#475569", fontSize: 11 }}>at ≥{threshold}% identity · {sequence.length} bp</div>
                </div>
                {results.length > 0 && (
                  <button onClick={addAll} style={{ background: "#4ade80", color: "#0a0f1e", border: "none", borderRadius: 7, padding: "8px 14px", fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "monospace" }}>
                    Add All
                  </button>
                )}
              </div>

              {results.length > 0 && (
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  {allTypes.map(t => (
                    <button key={t} onClick={() => setFilterType(t)}
                      style={{ background: filterType === t ? (TYPE_COLORS[t] || "#4ade80") : "#1e293b", color: filterType === t ? "#0a0f1e" : "#64748b", border: "none", borderRadius: 20, padding: "4px 12px", fontSize: 10, fontWeight: 700, cursor: "pointer", fontFamily: "monospace", transition: "all 0.15s" }}>
                      {t}
                    </button>
                  ))}
                </div>
              )}

              {results.length === 0 && (
                <div style={{ color: "#334155", fontSize: 13, textAlign: "center", padding: "24px 0" }}>
                  No elements found. Try lowering the identity threshold.
                </div>
              )}

              {(filtered || []).map((hit, i) => {
                const globalIdx = results.indexOf(hit);
                const isAdded = added.has(globalIdx);
                const color = TYPE_COLORS[hit.type] || "#64748b";
                const pct = Math.round(hit.identity * 100);
                return (
                  <div key={i} style={{ background: "#0f172a", border: `1px solid ${isAdded ? "#4ade8040" : "#1e293b"}`, borderRadius: 10, padding: "12px 14px", display: "flex", flexDirection: "column", gap: 8 }}>
                    <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
                      <div style={{ width: 10, height: 10, borderRadius: 2, background: color, flexShrink: 0, marginTop: 3 }} />
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontWeight: 700, fontSize: 13, color: "#e2e8f0", marginBottom: 4 }}>
                          {hit.name}
                          {hit.custom && <span style={{ marginLeft: 6, fontSize: 9, background: "#a78bfa22", color: "#a78bfa", borderRadius: 4, padding: "1px 6px", fontWeight: 700 }}>custom</span>}
                        </div>
                        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                          <span style={{ background: color + "22", color, borderRadius: 4, padding: "1px 7px", fontSize: 10, fontWeight: 700 }}>{hit.type}</span>
                          <span style={{ color: "#64748b", fontSize: 11 }}>{hit.start + 1}–{hit.end + 1}</span>
                          <span style={{ color: "#64748b", fontSize: 11 }}>{hit.end - hit.start + 1} bp</span>
                          <span style={{ color: "#64748b", fontSize: 11 }}>{hit.strand === 1 ? "→ fwd" : "← rev"}</span>
                        </div>
                      </div>
                      <button
                        onClick={() => addHit(hit, globalIdx)}
                        disabled={isAdded}
                        style={{ background: isAdded ? "#1e293b" : "#4ade80", color: isAdded ? "#475569" : "#0a0f1e", border: "none", borderRadius: 7, padding: "6px 12px", fontSize: 11, fontWeight: 700, cursor: isAdded ? "default" : "pointer", fontFamily: "monospace", flexShrink: 0 }}
                      >
                        {isAdded ? "✓" : "Add"}
                      </button>
                    </div>
                    <div>
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
                        <span style={{ color: "#475569", fontSize: 9 }}>IDENTITY</span>
                        <span style={{ color: pct >= 95 ? "#4ade80" : pct >= 85 ? "#fbbf24" : "#f97316", fontSize: 11, fontWeight: 700 }}>{pct}%</span>
                      </div>
                      <div style={{ height: 4, background: "#1e293b", borderRadius: 3, overflow: "hidden" }}>
                        <div style={{ height: "100%", width: pct + "%", background: pct >= 95 ? "#4ade80" : pct >= 85 ? "#fbbf24" : "#f97316", borderRadius: 3 }} />
                      </div>
                    </div>
                  </div>
                );
              })}
            </>
          )}
        </>
      )}

      {/* ── DATABASE PANEL ── */}
      {dbTab === "database" && (
        <>
          {/* Add new element form */}
          <div style={{ background: "#0f172a", border: "1px solid #1e293b", borderRadius: 12, padding: 14, display: "flex", flexDirection: "column", gap: 10 }}>
            <div style={{ color: "#4ade80", fontSize: 11, fontWeight: 700, letterSpacing: "0.1em" }}>+ ADD CUSTOM ELEMENT</div>

            <input
              value={newEl.name}
              onChange={e => setNewEl(p => ({ ...p, name: e.target.value }))}
              placeholder="Element name (e.g. my-promoter-X)"
              style={inputSt}
            />

            <select
              value={newEl.type}
              onChange={e => setNewEl(p => ({ ...p, type: e.target.value }))}
              style={{ ...inputSt, cursor: "pointer" }}
            >
              {ELEMENT_TYPES.map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>

            <textarea
              value={newEl.seq}
              onChange={e => setNewEl(p => ({ ...p, seq: e.target.value }))}
              placeholder="Paste the reference sequence (A/T/G/C)…"
              rows={4}
              style={{ ...inputSt, color: "#4ade80", lineHeight: 1.6, resize: "vertical" }}
              spellCheck={false}
              autoCapitalize="characters"
              autoCorrect="off"
            />

            {newEl.seq && (
              <div style={{ fontSize: 10, color: "#475569" }}>
                {cleanSeq(newEl.seq).length} bp · GC {gcPct(cleanSeq(newEl.seq))}%
              </div>
            )}

            {elError && (
              <div style={{ color: "#f87171", fontSize: 11 }}>⚠ {elError}</div>
            )}

            <button
              onClick={handleAddCustomEl}
              style={{ background: "#4ade80", color: "#0a0f1e", border: "none", borderRadius: 8, padding: 11, fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "monospace" }}
            >
              Add to Database
            </button>
          </div>

          {/* Custom element list */}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div style={{ fontSize: 10, color: "#475569", letterSpacing: "0.1em" }}>
              CUSTOM ELEMENTS ({customDb.length})
            </div>
            {customDb.length > 0 && (
              <button
                onClick={() => { if (window.confirm("Remove all custom elements?")) onCustomDbChange([]); }}
                style={{ background: "none", border: "none", color: "#f87171", fontSize: 11, cursor: "pointer", fontFamily: "monospace" }}
              >
                Clear all
              </button>
            )}
          </div>

          {/* Type filter chips */}
          {customDb.length > 1 && (
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
              {customTypes.map(t => (
                <button key={t} onClick={() => setDbFilter(t)}
                  style={{ background: dbFilter === t ? (TYPE_COLORS[t] || "#4ade80") : "#1e293b", color: dbFilter === t ? "#0a0f1e" : "#64748b", border: "none", borderRadius: 20, padding: "4px 12px", fontSize: 10, fontWeight: 700, cursor: "pointer", fontFamily: "monospace", transition: "all 0.15s" }}>
                  {t}
                </button>
              ))}
            </div>
          )}

          {customDb.length === 0 ? (
            <div style={{ color: "#334155", fontSize: 13, textAlign: "center", padding: "32px 16px", lineHeight: 1.7 }}>
              No custom elements yet.<br />Add one above to include it in future annotations.
            </div>
          ) : (
            dbFiltered.map((el, i) => {
              const origIdx = customDb.indexOf(el);
              const color = TYPE_COLORS[el.type] || "#64748b";
              return (
                <div key={i} style={{ background: "#0f172a", border: "1px solid #1e293b", borderRadius: 10, padding: "12px 14px", display: "flex", flexDirection: "column", gap: 6 }}>
                  <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
                    <div style={{ width: 10, height: 10, borderRadius: 2, background: color, flexShrink: 0, marginTop: 3 }} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontWeight: 700, fontSize: 13, color: "#e2e8f0", marginBottom: 4 }}>{el.name}</div>
                      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                        <span style={{ background: color + "22", color, borderRadius: 4, padding: "1px 7px", fontSize: 10, fontWeight: 700 }}>{el.type}</span>
                        <span style={{ color: "#64748b", fontSize: 11 }}>{el.seq.length} bp</span>
                        <span style={{ color: "#64748b", fontSize: 11 }}>GC {gcPct(el.seq)}%</span>
                      </div>
                    </div>
                    <button
                      onClick={() => removeCustomEl(origIdx)}
                      style={{ background: "none", border: "none", color: "#f87171", cursor: "pointer", fontSize: 16, padding: "0 4px", lineHeight: 1, flexShrink: 0 }}
                    >
                      ×
                    </button>
                  </div>
                  <div style={{ color: "#334155", fontSize: 10, fontFamily: "monospace", wordBreak: "break-all", marginTop: 2 }}>
                    {el.seq.slice(0, 60)}{el.seq.length > 60 ? "…" : ""}
                  </div>
                </div>
              );
            })
          )}

          {/* Export / import */}
          {customDb.length > 0 && (
            <div style={{ display: "flex", gap: 8 }}>
              <button
                onClick={() => {
                  const json = JSON.stringify(customDb, null, 2);
                  const blob = new Blob([json], { type: "application/json" });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement("a");
                  a.href = url; a.download = "custom-elements.json"; a.click();
                  URL.revokeObjectURL(url);
                }}
                style={{ flex: 1, background: "#1e293b", color: "#94a3b8", border: "none", borderRadius: 8, padding: 10, fontSize: 12, cursor: "pointer", fontFamily: "monospace" }}
              >
                ↓ Export JSON
              </button>
            </div>
          )}

          {/* Import JSON */}
          <div style={{ position: "relative" }}>
            <input
              type="file"
              accept=".json"
              onChange={e => {
                const file = e.target.files[0];
                if (!file) return;
                file.text().then(text => {
                  try {
                    const parsed = JSON.parse(text);
                    if (!Array.isArray(parsed)) throw new Error("Expected JSON array");
                    const valid = parsed.filter(el => el.name && el.seq && el.type);
                    if (!valid.length) throw new Error("No valid elements found");
                    const cleaned = valid.map(el => ({ ...el, seq: cleanSeq(el.seq), custom: true }));
                    onCustomDbChange([...customDb, ...cleaned]);
                    setElError("");
                  } catch (err) {
                    setElError("Import failed: " + err.message);
                  }
                });
                e.target.value = "";
              }}
              style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: 0, cursor: "pointer", zIndex: 2 }}
            />
            <div style={{ border: "1px dashed #334155", borderRadius: 8, padding: "10px 14px", textAlign: "center", fontSize: 12, color: "#475569", pointerEvents: "none" }}>
              ↑ Import from JSON
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────────────────────
export default function DNAEditor() {
  const [sequence,    setSequence]    = useState(SAMPLES.pUC19);
  const [rawInput,    setRawInput]    = useState(SAMPLES.pUC19);
  const [seqName,     setSeqName]     = useState("pUC19");
  const [tab,         setTab]         = useState("linear");
  const [showComp,    setShowComp]    = useState(false);
  const [features,    setFeatures]    = useState(DEMO_FEATURES);
  const [selection,   setSelection]   = useState(null);
  const [selAnchor,   setSelAnchor]   = useState(null);
  const [findStr,     setFindStr]     = useState("");
  const [findHits,    setFindHits]    = useState([]);
  const [findIdx,     setFindIdx]     = useState(0);
  const [sample,      setSample]      = useState("pUC19");
  const [showSamples, setShowSamples] = useState(false);
  const [addingFeat,  setAddingFeat]  = useState(false);
  const [newFeat,     setNewFeat]     = useState({ name: "", start: "", end: "" });
  const [fileMsg,     setFileMsg]     = useState({ text: "", ok: true });

  // Custom element database — persisted to localStorage
  const [customDb, setCustomDb] = useState(() => {
    try {
      const saved = localStorage.getItem("helixlab-custom-db");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  function handleCustomDbChange(newDb) {
    setCustomDb(newDb);
    try { localStorage.setItem("helixlab-custom-db", JSON.stringify(newDb)); } catch {}
  }

  const inputStyle = {
    background: "#1e293b", border: "1px solid #334155", borderRadius: 8,
    color: "#e2e8f0", fontFamily: "'JetBrains Mono', monospace",
    fontSize: 13, padding: "10px 12px", outline: "none",
    width: "100%", boxSizing: "border-box",
  };

  function loadSample(key) {
    setSample(key);
    setShowSamples(false);
    setRawInput(SAMPLES[key]);
    setSequence(SAMPLES[key]);
    setSeqName(key);
    setSelection(null);
    setFeatures(DEMO_FEATURES);
    setFileMsg({ text: "", ok: true });
  }

  function handleRaw(val) {
    setRawInput(val);
    setSequence(cleanSeq(val));
    setSelection(null);
  }

  const handleFileLoad = useCallback((result, filename) => {
    setSequence(result.sequence);
    setRawInput(result.sequence);
    setSeqName(result.name || filename);
    setSample("");
    setFeatures(result.features.length > 0 ? result.features : []);
    setSelection(null);
    setSelAnchor(null);
    const msg = `✓ Loaded "${result.name || filename}" (${result.sequence.length} bp${result.features.length ? `, ${result.features.length} features` : ""})`;
    setFileMsg({ text: msg, ok: true });
    setTab("linear");
    setTimeout(() => setFileMsg({ text: "", ok: true }), 4000);
  }, []);

  const handleFileError = useCallback(msg => {
    setFileMsg({ text: "⚠ " + msg, ok: false });
    setTimeout(() => setFileMsg({ text: "", ok: true }), 5000);
  }, []);

  function onTapBase(idx) {
    if (selAnchor === null) {
      setSelAnchor(idx);
      setSelection([idx, idx]);
    } else {
      setSelection([selAnchor, idx]);
      setSelAnchor(null);
    }
  }

  function clearSel() {
    setSelection(null);
    setSelAnchor(null);
  }

  function doFind() {
    if (!findStr) { setFindHits([]); return; }
    const up = findStr.toUpperCase();
    const hits = [];
    let i = 0;
    while ((i = sequence.indexOf(up, i)) !== -1) { hits.push(i); i++; }
    setFindHits(hits);
    setFindIdx(0);
    if (hits.length) setSelection([hits[0], hits[0] + up.length - 1]);
  }

  function nextHit() {
    if (!findHits.length) return;
    const n = (findIdx + 1) % findHits.length;
    setFindIdx(n);
    setSelection([findHits[n], findHits[n] + findStr.length - 1]);
  }

  function addFeature() {
    const s = parseInt(newFeat.start) || 0;
    const e = parseInt(newFeat.end) || 10;
    setFeatures(prev => [...prev, {
      name: newFeat.name || "Feature", start: s, end: e,
      color: FEAT_COLORS[prev.length % FEAT_COLORS.length], strand: 1,
    }]);
    setNewFeat({ name: "", start: "", end: "" });
    setAddingFeat(false);
  }

  const handleAddAnnotations = useCallback(newFeats => {
    setFeatures(prev => {
      const existing = new Set(prev.map(f => `${f.name}:${f.start}:${f.end}`));
      return [...prev, ...newFeats.filter(f => !existing.has(`${f.name}:${f.start}:${f.end}`))];
    });
    setTab("plasmid");
  }, []);

  const selSeq = selection != null
    ? sequence.slice(Math.min(selection[0], selection[1]), Math.max(selection[0], selection[1]) + 1)
    : "";

  const TABS = [
    { id: "linear",  icon: "⟷", label: "Linear"  },
    { id: "plasmid", icon: "◎", label: "Plasmid" },
    { id: "annotate",icon: "⬡", label: "Annotate"},
    { id: "edit",    icon: "✎", label: "Edit"    },
  ];

  return (
    <div style={{ minHeight: "100vh", background: "#0a0f1e", color: "#e2e8f0", fontFamily: "'JetBrains Mono', monospace", display: "flex", flexDirection: "column", maxWidth: 640, margin: "0 auto" }}>
      <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700&family=Syne:wght@700;800&display=swap" rel="stylesheet" />

      {/* Header */}
      <div style={{ background: "#0f172a", borderBottom: "1px solid #1e293b", padding: "12px 16px", display: "flex", alignItems: "center", gap: 12, position: "sticky", top: 0, zIndex: 20 }}>
        <div>
          <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 18, fontWeight: 800, color: "#4ade80", letterSpacing: "-0.02em" }}>⬡ VibeGene</div>
          <div style={{ fontSize: 9, color: "#334155", letterSpacing: "0.1em" }}>DNA EDITOR</div>
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          {seqName && <div style={{ color: "#64748b", fontSize: 11, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", paddingLeft: 8 }}>{seqName}</div>}
        </div>
      </div>

      {/* Toast */}
      {fileMsg.text && (
        <div style={{ background: fileMsg.ok ? "rgba(74,222,128,0.1)" : "rgba(248,113,113,0.1)", borderBottom: `1px solid ${fileMsg.ok ? "#4ade8040" : "#f8717140"}`, padding: "8px 16px", fontSize: 12, color: fileMsg.ok ? "#4ade80" : "#f87171", fontFamily: "monospace" }}>
          {fileMsg.text}
        </div>
      )}

      {/* Find bar */}
      {tab === "linear" && (
        <div style={{ background: "#0f172a", borderBottom: "1px solid #1e293b", padding: "8px 16px", display: "flex", gap: 8, alignItems: "center" }}>
          <input
            value={findStr}
            onChange={e => setFindStr(e.target.value)}
            onKeyDown={e => e.key === "Enter" && doFind()}
            placeholder="Find motif…"
            style={{ ...inputStyle, padding: "6px 10px", fontSize: 12, flex: 1 }}
          />
          <button onClick={doFind} style={{ background: "#4ade80", color: "#0a0f1e", border: "none", borderRadius: 7, padding: "6px 14px", fontWeight: 700, fontSize: 12, cursor: "pointer", fontFamily: "monospace", whiteSpace: "nowrap" }}>Find</button>
          {findHits.length > 0 && (
            <button onClick={nextHit} style={{ background: "#1e293b", color: "#94a3b8", border: "none", borderRadius: 7, padding: "6px 10px", fontSize: 12, cursor: "pointer", whiteSpace: "nowrap" }}>
              {findIdx + 1}/{findHits.length} →
            </button>
          )}
          {findHits.length === 0 && findStr && <span style={{ color: "#f87171", fontSize: 11 }}>–</span>}
        </div>
      )}

      {/* Content */}
      <div style={{ flex: 1, overflowY: "auto", padding: "16px 16px 8px" }}>

        {/* Linear tab */}
        {tab === "linear" && (
          <>
            <div style={{ display: "flex", gap: 8, marginBottom: 12, alignItems: "center", flexWrap: "wrap" }}>
              <label style={{ display: "flex", alignItems: "center", gap: 6, color: "#64748b", fontSize: 11, cursor: "pointer" }}>
                <input type="checkbox" checked={showComp} onChange={e => setShowComp(e.target.checked)} style={{ accentColor: "#4ade80" }} />
                Complement
              </label>
              {selAnchor !== null && <span style={{ color: "#fbbf24", fontSize: 11 }}>Tap end base to finish…</span>}
              {selection != null && selAnchor === null && (
                <button onClick={clearSel} style={{ background: "none", border: "none", color: "#475569", fontSize: 11, cursor: "pointer", fontFamily: "monospace", padding: 0 }}>✕ clear</button>
              )}
            </div>
            {sequence.length === 0
              ? <div style={{ color: "#334155", textAlign: "center", marginTop: 60, fontSize: 14 }}>Load a sample or upload a file in the Edit tab</div>
              : <SequenceViewer sequence={sequence} selection={selection} onTapBase={onTapBase} showComp={showComp} />
            }
          </>
        )}

        {/* Plasmid tab */}
        {tab === "plasmid" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <PlasmidMap sequence={sequence} features={features} />
            <div style={{ fontSize: 10, color: "#475569", letterSpacing: "0.1em", marginTop: 4 }}>FEATURES ({features.length})</div>
            {features.length === 0 && <div style={{ color: "#334155", fontSize: 12 }}>No features. Use the Annotate tab or add manually.</div>}
            {features.map((f, i) => (
              <div key={i} style={{ display: "flex", gap: 10, alignItems: "center", background: "#0f172a", borderRadius: 8, padding: "10px 14px", border: "1px solid #1e293b" }}>
                <div style={{ width: 10, height: 10, borderRadius: 2, background: f.color || TYPE_COLORS[f.type] || "#64748b", flexShrink: 0 }} />
                <span style={{ fontWeight: 700, flex: 1, fontSize: 13 }}>{f.name}</span>
                <span style={{ color: "#64748b", fontSize: 11 }}>{f.start}–{f.end}</span>
                <span style={{ color: "#475569", fontSize: 11 }}>{f.strand === 1 ? "→" : "←"}</span>
                <button onClick={() => setFeatures(prev => prev.filter((_, j) => j !== i))} style={{ background: "none", border: "none", color: "#f87171", cursor: "pointer", fontSize: 16, padding: "0 4px", lineHeight: 1 }}>×</button>
              </div>
            ))}
            {addingFeat ? (
              <div style={{ background: "#0f172a", border: "1px solid #334155", borderRadius: 10, padding: 14, display: "flex", flexDirection: "column", gap: 10 }}>
                <input value={newFeat.name} onChange={e => setNewFeat(p => ({ ...p, name: e.target.value }))} placeholder="Feature name" style={inputStyle} />
                <div style={{ display: "flex", gap: 8 }}>
                  <input value={newFeat.start} onChange={e => setNewFeat(p => ({ ...p, start: e.target.value }))} placeholder="Start" type="number" style={{ ...inputStyle, flex: 1 }} />
                  <input value={newFeat.end}   onChange={e => setNewFeat(p => ({ ...p, end: e.target.value }))}   placeholder="End"   type="number" style={{ ...inputStyle, flex: 1 }} />
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <button onClick={addFeature} style={{ flex: 1, background: "#4ade80", color: "#0a0f1e", border: "none", borderRadius: 8, padding: 12, fontWeight: 700, fontSize: 13, cursor: "pointer", fontFamily: "monospace" }}>Add</button>
                  <button onClick={() => setAddingFeat(false)} style={{ flex: 1, background: "#1e293b", color: "#f87171", border: "none", borderRadius: 8, padding: 12, fontWeight: 700, fontSize: 13, cursor: "pointer", fontFamily: "monospace" }}>Cancel</button>
                </div>
              </div>
            ) : (
              <button onClick={() => setAddingFeat(true)} style={{ background: "#0f172a", color: "#4ade80", border: "1px dashed #334155", borderRadius: 10, padding: 12, fontSize: 13, cursor: "pointer", fontFamily: "monospace", fontWeight: 700 }}>+ Add Feature</button>
            )}
          </div>
        )}

        {tab === "annotate" && (
          <AnnotateTab sequence={sequence} onAddFeatures={handleAddAnnotations} customDb={customDb} onCustomDbChange={handleCustomDbChange} />
        )}

        {/* Edit tab */}
        {tab === "edit" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div style={{ fontSize: 10, color: "#64748b", letterSpacing: "0.1em" }}>UPLOAD FILE</div>
            <FileUpload onLoad={handleFileLoad} onError={handleFileError} />
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {[
                { ext: ".fasta / .fa", desc: "FASTA — header + raw sequence", icon: "📄" },
                { ext: ".gb / .gbk",   desc: "GenBank — sequence + features",  icon: "🗂" },
                { ext: ".dna",         desc: "SnapGene — binary with features", icon: "🔬" },
              ].map(f => (
                <div key={f.ext} style={{ display: "flex", gap: 10, alignItems: "center", background: "#0f172a", borderRadius: 8, padding: "8px 12px", border: "1px solid #1e293b" }}>
                  <span style={{ fontSize: 16 }}>{f.icon}</span>
                  <div>
                    <div style={{ color: "#4ade80", fontSize: 11, fontWeight: 700 }}>{f.ext}</div>
                    <div style={{ color: "#475569", fontSize: 10 }}>{f.desc}</div>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ borderTop: "1px solid #1e293b", paddingTop: 14 }}>
              <div style={{ fontSize: 10, color: "#64748b", letterSpacing: "0.1em", marginBottom: 10 }}>OR PASTE / TYPE SEQUENCE</div>
              <textarea
                value={rawInput}
                onChange={e => handleRaw(e.target.value)}
                rows={8}
                style={{ ...inputStyle, color: "#4ade80", lineHeight: 1.7, letterSpacing: "0.05em", resize: "vertical" }}
                placeholder="Paste DNA here…"
                spellCheck={false}
                autoCapitalize="characters"
                autoCorrect="off"
              />
            </div>
            <button onClick={() => { const rc = revComp(sequence); setSequence(rc); setRawInput(rc); }} style={{ background: "#1e293b", color: "#60a5fa", border: "none", borderRadius: 8, padding: 12, fontSize: 13, cursor: "pointer", fontWeight: 700, fontFamily: "monospace" }}>
              ↺ Reverse Complement
            </button>
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={() => navigator.clipboard.writeText(sequence)} style={{ flex: 1, background: "#1e293b", color: "#94a3b8", border: "none", borderRadius: 8, padding: 12, fontSize: 13, cursor: "pointer", fontFamily: "monospace" }}>Copy</button>
              <button onClick={() => { setSequence(""); setRawInput(""); setSelection(null); setSeqName(""); }} style={{ flex: 1, background: "#1e293b", color: "#f87171", border: "none", borderRadius: 8, padding: 12, fontSize: 13, cursor: "pointer", fontFamily: "monospace" }}>Clear</button>
            </div>
          </div>
        )}
      </div>

      <StatsDrawer sequence={sequence} selSeq={selSeq} />

      {/* Bottom nav */}
      <div style={{ display: "flex", background: "#0f172a", borderTop: "1px solid #1e293b", position: "sticky", bottom: 0, zIndex: 20 }}>
        {TABS.map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            style={{ flex: 1, background: tab === t.id ? "rgba(74,222,128,0.05)" : "none", border: "none", borderTop: tab === t.id ? "2px solid #4ade80" : "2px solid transparent", color: tab === t.id ? "#4ade80" : "#475569", padding: "11px 4px 9px", display: "flex", flexDirection: "column", alignItems: "center", gap: 2, cursor: "pointer", fontFamily: "'JetBrains Mono', monospace", transition: "color 0.15s", WebkitTapHighlightColor: "transparent" }}
          >
            <span style={{ fontSize: 16, lineHeight: 1 }}>{t.icon}</span>
            <span style={{ fontSize: 8, fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase" }}>{t.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
